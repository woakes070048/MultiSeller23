<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'تقرير المتواجدون الآن';

// Text
$_['text_list'] = 'قائمة';
$_['text_guest'] = 'زائر';

// Column
$_['column_ip'] = 'الآي بي - IP';
$_['column_seller'] = 'البائع';
$_['column_url'] = 'آخر صفحة تم زيارتها';
$_['column_referer'] = 'المرجع';
$_['column_date_added'] = 'آخر نقرة';
$_['column_action'] = 'تحرير';

// Entry
$_['entry_ip'] = 'الآي بي - IP';
$_['entry_seller'] = 'البائع';
